package main

import (
	"context"
	"fmt"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
)

func handler(ctx context.Context, request events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	// Procesar la solicitud recibida
	name := request.QueryStringParameters["name"]
	message := fmt.Sprintf("Hola, %s! Esta es una función Lambda en Go.", name)

	// Construir la respuesta
	response := events.APIGatewayProxyResponse{
		StatusCode: 200,
		Headers:    map[string]string{"Content-Type": "text/plain"},
		Body:       message,
	}

	return response, nil
}

func main() {
	lambda.Start(handler)
}
